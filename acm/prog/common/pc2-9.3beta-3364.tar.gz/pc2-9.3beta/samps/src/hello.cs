/*
 *
 * File:    hello.cs
 * Purpose: prints Hello World.
 * pc2@ecs.csus.edu at http://www.ecs.csus.edu/pc2
 *
 * $Id: hello.cs 3210 2015-10-17 00:21:33Z boudreat $
*/
using System;
 
public class HelloWorld
{
    static public void Main ()
    {
        Console.WriteLine ("Hello World.");
    }
}
