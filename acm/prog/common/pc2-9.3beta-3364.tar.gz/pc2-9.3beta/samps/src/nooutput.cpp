
//
// File:    nooutput.cpp
// Purpose: exits with no output
// Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
//
// $Id: nooutput.cpp 3210 2015-10-17 00:21:33Z boudreat $
//

using namespace std;

main()
{
}

// eof 
