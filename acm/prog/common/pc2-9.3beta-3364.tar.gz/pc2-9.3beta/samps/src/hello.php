<?
//
// File:    hello.php
// Purpose: prints Hello World.
// Author:  pc2@ecs.csus.edu at http://www.ecs.csus.edu/pc2
//
// $Id: hello.php 2367 2011-10-02 03:04:40Z laned $
//
print "Hello World.";
?>
