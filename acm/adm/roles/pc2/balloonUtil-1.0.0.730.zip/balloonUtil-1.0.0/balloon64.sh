#!/bin/bash
#
# Purpose: to run a balloon manager
#

set -e
VER="Version 1.0.0 (3/13/2015)"

LIBDIR=$( dirname "${BASH_SOURCE}[0]" )/lib
UNAME=$( uname  -s )
vmoptions=
swtjar=swt-gtk-linux-x86_64.jar
if [ "$UNAME" == "Darwin" ]; then
   vmoptions=-XstartOnFirstThread
   swtjar=swt-cocoa-macosx-x86_64.jar
fi
jar=balloonUtil.jar
mainclass=org.acmicpc.balloon.BalloonUtility

# workaround java not looking at LC_PAPER
if [[ "x$LC_ALL" != "x" && "x$LC_PAPER" != "x" && $LC_PAPER != $LC_ALL ]]; then 
LC_ALL=$LC_PAPER
fi
java $vmoptions -cp "$LIBDIR/$jar":"$LIBDIR/$swtjar" $mainclass $*

