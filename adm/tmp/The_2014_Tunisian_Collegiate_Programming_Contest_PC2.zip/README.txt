File format:

PC2_Contest.tab
contest Id\tcontest full name\tcontest short name\tcontest geographic area\thosts\tsponsors\temail\thome page\tstanding URL\treport URL\tM\tcontest abbreviation\tprimary site Id\tcertificate line 1\tcertificate line 2

PC2_Site.tab
site Id\tcontest Id\tsite name\tsite email\tsite home page\tC\tlocation\texecution date

PC2_Team.tab
reservation Id\tsite Id\tteam status\tteam name\tinstitution name\tinstitution short name\tinstitution home page\tinstitution country\twhether institution has graduate program(Y/N)

_PC2_Team.tab
team order number\treservation Id\tsite Id\tteam status\tteam name\tinstitution name\tinstitution short name\tinstitution home page\tinstitution country\twhether institution has graduate program(Y/N)
